
// const cars = ["Saab","Volvo","BMW"];
// const name = ["Saab1","Volvo2","BMW3"];

// document.getElementById("demo7").innerHTML = cars[0]
// document.getElementById("demo8").innerHTML = cars[1];

// var x = myFunction(10, 3);
// document.getElementById("demo7").innerHTML = x;

// function myFunction(a, b) {
//   return a * b;
// }
const car = {type:"Fiat", model:"500", color:"white",speed:"160"};

// Display some data from the object:
document.getElementById("demo7").innerHTML = "The car speed is " + car.speed;

// document.getElementById('demo10').innerHTML=Date();