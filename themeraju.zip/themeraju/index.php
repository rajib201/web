<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php wp_head();?>
</head>
<body>
    <!-- header part start -->
<header class="slider container-fluid px-0">
    <?php
    $qry1= new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slid'
    ]);
    ?>
 <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">

    <?php 
    $x=0;
    while($qry1->have_posts()){$qry1->the_post(); 
    $x++;
    ?>
    <div class="carousel-item <?= ($x==1)?'active':''?>">
        <?php the_post_thumbnail();?>
      
    </div>
    <?php } ?>

   
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
 </header>
  <!-- header part end -->
  <!-- logo part start -->
  <section class="container-fluid logo pl-2">
    <div class="row">
        <div class="col-sm-6 logo_left">
            <?php the_custom_logo();?>
        </div>
        <div class="col-sm-6 logo_right text-end">
            <?php dynamic_sidebar('ltr');?>
        </div>
    </div>
 </section>



  <!-- logo part end -->
  <!-- menu part start -->
  <section class="container-fluid mt-0 ">
  <div class="container navbar-expand ">
  <?php 
        wp_nav_menu(array(
            'theme_location'=>'TM',
            'menu_class'=>'navbar-nav menu_2'
        ) );
        ?>
  </div>
</section>
  <!-- menu part end -->
  <!-- hero part start -->
  <section class="container-fluid hero">
    <div class="row">
        <div class="col sm-1"></div>
        <div class="col sm-10">
            <h1>Welcome to PADMA MULTIPURPOSE BRIDGE PROJECT</h1>
            <p>The Padma Bridge is a multipurpose road-rail bridge across the Padma River to be constructed in Bangladesh. When completed it will be the largest bridge in Bangladesh and the first fixed river crossing for road traffic. It will connect Louhajong, Munshiganj to Shariatpur and Madaripur, linking the south-west of the country, to northern and eastern regions.</p>
            <?php dynamic_sidebar('card_img');?>



        </div>
        <div class="col sm-1"></div>
    </div>
    <div class="col-sm-5">
    <img src="<?php echo get_template_directory_uri().'/assets/images/download.png'?>" alt="">
    </div>
  </div>
  <div class="row">
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('card_img');?>
            <div class="card-body">
              <?php dynamic_sidebar('card_body');?>
            </div>
          </div>                                                              
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('card_img_2');?>
            <div class="card-body">
              <?php dynamic_sidebar('card_body_2');?>
            </div>
          </div>
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('card_img_3');?>
            <div class="card-body">
              <?php dynamic_sidebar('card_body_3');?>
            </div>
          </div>                                                              
    </div>

  </section>

  <!-- jk -->

  <section class="container photo text-center mt-5 mb-5">
  <div class="row">
    <div class="col-sm-5">
      <img src="<?php echo get_template_directory_uri().'/assets/images/bg_line_green2.png'?>" alt="">
    </div>
    <div class="col-sm-2">
      <h4>Recent Photos</h4>
      <p>Some latest project pictures</p>
    </div>
    <div class="col-sm-5">
    <img src="<?php echo get_template_directory_uri().'/assets/images/download.png'?>" alt="">
    </div>
  </div>
  <div class="row">
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg1');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext1');?>
            </div>
          </div>                                                              
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg2');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext2');?>
            </div>
          </div>
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg3');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext3');?>
            </div>
          </div>                                                              
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg4');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext4');?>
            </div>
          </div>                                                              
    </div>
  </div>
</section>
  <!-- jk -->







  <!-- hero part end -->
  <section class="container-fluid news">
    <div class="row">
        <div class="col-sm-5"></div>
        <div class="col-sm-2">
            <h1>News & Events</h1>
        </div>
        <div class="col-sm-5"></div>

    </div>
  </section>
  <footer class="container-fluid footer_main mt-5">
<div class="row">
  <div class="col-lg-6 footer_left" style="width: 30rem;" >
    <?php dynamic_sidebar('footer_left'); ?>
  </div>
  <div class="col-lg-6 footer_right " style="width: 30rem;">
      <?php dynamic_sidebar('footer_right') ?>
  </div>
</div>

</footer>








<?php wp_footer();?>
    
</body>
</html>