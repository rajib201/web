<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php wp_head();?>
</head>
<body>
    <!-- header slider part start -->
    <header class="container-fluid slider px-0">
                    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
            <?php
            $x=0;
            while(have_posts()){the_post();
                $x++;
            ?>
                    <div class="carousel-item <?=($x==1)?'active':''?>">
                    <?php the_post_thumbnail();?>
                
                    </div>
                   <?php }?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
    </header>


    <!-- header slider part end -->
    <!-- logo part start -->
<section class="container-fluid logo">
    <div class="row">
        <div class="col-lg-6 logo_left">
        <?php the_custom_logo();?>

        </div>
        
        <div class="col-lg-6 logo_right text-end">
            <?php dynamic_sidebar('logosecond');?>
        </div>
    </div>
</section>
 
    <!-- logo part end -->
    <!-- hero part start -->
    <section class="container photo">
        <div class="row text-center">
            <div class="col-sm-5">
              <img src="<?php get_template_directory_uri().'/Assets/images/logo/Pier_7A_to_7F.jpg'?>;" alt="">
            </div>
            <div class="col-sm-2">
                <h4>Recent Photos</h4>
                <p>Some latest project pictures</p>
            </div>
            <div class="col-sm-5">
               <img src="<?php get_template_directory_uri().'/Assets/images/logo/Launching of Steel Truss 7A between P37 & P38.jpg'?>;" alt="">
            </div>
        </div>
        
        <div class="row">
            <div class="col-sm-3">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('photosone');?>
       
        <div class="card-body">
        <?php dynamic_sidebar('textone');?>

            
        </div>
        </div>
            </div>
            <div class="col-sm-3">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('phototwo');?>
       
        <div class="card-body">
        <?php dynamic_sidebar('texttwo');?>

          
        </div>
        </div>
            </div>
            <div class="col-sm-3">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('photothree');?>
       
        <div class="card-body">
        <?php dynamic_sidebar('textthree');?>
            
        </div>
        </div>
            </div>
            <div class="col-sm-3">
            <div class="card" style="width: 16rem;">
            <?php dynamic_sidebar('photofour');?>
       
        <div class="card-body">
        <?php dynamic_sidebar('textfour');?>
            
        </div>
        </div>
            </div>
        </div>

    </section>
 
    <!-- hero part end -->
    <!-- news part start -->
    <section class="container news">
        <div class="row text-center">
            <div class="col-sm-5">
            <img src="<?php get_template_directory_uri().'/Assets/images/logo/Pier_7A_to_7F.jpg'?>;" alt="">
            </div>
            <div class="col-sm-2"></div>
            <div class="col-sm-5"></div>

        </div>
    </section>
    <!-- news part start -->
   


<?php wp_footer();?>
</body>
</html>