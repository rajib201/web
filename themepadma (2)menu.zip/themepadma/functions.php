<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boostrap', get_template_directory_uri().'/asss/css/bootstrap.min.css' );
wp_enqueue_script( 'script-javascript', get_template_directory_uri() . '/asss/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );

register_nav_menus([
    'PM'=>'Primary'
]);

register_sidebar([
    'name'=>'BD LOGO',
    'id'=>'bdlogo',
    'before_widget'=>'',
    'after_widget'=>''

]);
?>