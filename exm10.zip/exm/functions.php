<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri().'/asss/css/bootstrap.min.css' );
wp_enqueue_script( 'script-js', get_template_directory_uri() . '/asss/js/bootstrap.bundle.min.js', array(), '1.0.0', true );



add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );


register_sidebar([
    'name'=>'LOGO',
    'id'=>'logo',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_nav_menus([
    'TM'=>'Primary'
]);

register_sidebar([
    'name'=>'HERO TITLE',
    'id'=>'hero_title',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'HERO CARD1',
    'id'=>'card_1',
    'before_widget'=>'',
    'after_widget'=>''
]);


register_sidebar([
    'name'=>'LINE LEFT',
    'id'=>'lineleft',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'PHOTO TITLE',
    'id'=>'phototitle',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'LINE RIGHT',
    'id'=>'lineright',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'PHOTO CARD 1',
    'id'=>'photo_card_1',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'FOOTER TOP LEFT',
    'id'=>'ftleft',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'FOOTER TOP RIGHT',
    'id'=>'ftright',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'FB left',
    'id'=>'fbleft',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'FB RIGHT',
    'id'=>'fbright',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'NEWS TITLE',
    'id'=>'newstitle',
    'before_widget'=>'',
    'after_widget'=>''
]);
?>