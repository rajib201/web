<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>
    <link rel="stylesheet" href="style.css">
    

</head>
<body>
    
<div class="one">
  welcome

<h1>Rajib</h1>


<?php
echo ' This is my first program in php.';
?>

</div>

<div class="new">
    <h5>DPI</h5>
</div>
<div class="two">
<?php
$num1=564;
$num2='564';
$result=$num1+$num2;
echo ' The Multiplication='.$result;
if($num1===$num2){
    echo '<br>True';
}
else{
    echo'<br>Fasle<br>';
}
var_dump($num1);
print_r($result);

?>
<?php
$t = date("H");

if ($t < "20") {
  echo "<br> Have a good day!<br>";
}
?>

<?php


$i = 1; 

while
 ($i <= 6) 
{

  echo $i;
  $i++;
}

?>
<?php

$colors = array("<br>red", "green", "blue", "yellow "); 

foreach
 ($colors 
as
 $x) {
  echo $x;
}
?>
</div>


    
</body>
</html>